#include "MyFunction.h"

using namespace Cleaver;

MyFunction::MyFunction() : m_bounds(vec3::zero, vec3(30,30,30))
{
    // no allocation
}

MyFunction::~MyFunction()
{
    // no memory cleanup
}

BoundingBox MyFunction::bounds() const
{
    return m_bounds;
}

float MyFunction::valueAt(float x, float y, float z) const
{
    int dim_x = m_bounds.size.x;
    int dim_y = m_bounds.size.y;
    int dim_z = m_bounds.size.z;

    // Current Cleaver Limitation - Can't have material transitions on the boundary.
    // Will fix ASAP, but for now pad data with constant boundary.
    if(x < 2 || y < 2 || z < 2 || x > (dim_x - 3) || y > (dim_y - 3) || z > (dim_z - 3))
    {
        return 1.0;
    }

    float val = (x-dim_x/2)*(x-dim_x/2)+(y-dim_y/2)*(y-dim_y/2)+(z-dim_z/2) - 0.4*dim_x;
    return val;
}

